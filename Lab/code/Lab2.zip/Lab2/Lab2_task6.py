distance=int(input("Enter distance in kilometers: "))
print("The distance in meters is: ",distance*1000)
print("The distance in centimeters is: ",distance*100000)
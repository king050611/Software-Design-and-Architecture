higth=int(input("Enter the height : "))
base=int(input("Enter the base : "))
area=base*higth
print("The area of the triangle is : ",area)
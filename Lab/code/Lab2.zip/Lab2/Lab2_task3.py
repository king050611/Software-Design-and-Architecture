num1=int(input("Enter first number: "))
num2=int(input("Enter second number: "))
add=num1+num2
mul=num1*num2
divid=num1/num2
sub=num1-num2
print("The addition of two numbers is: ",add)
print("The multiplication of two numbers is: ",mul)
print("The division of two numbers is: ",divid)
print("The subtraction of two numbers is: ",sub)
x=int(input())
y=int(input())
z=int(input())
output=(4*x+3*y)/2*z
print(output)